No more hovering over hoverable elements while the game is not focused
### KNOWN ISSUES:
- Still a hover UI element that vaguely follows the cursor